#ifndef KRUSKAL_INCLUDE
#define KRUSKAL_INCLUDE
graph kruskal(graph g);     // takes a graph as input and returns a graph instance with mst
#endif // KRUSKAL_INCLUDE
