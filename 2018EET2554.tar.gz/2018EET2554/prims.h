#ifndef PRIMS_H_INCLUDE
#define PRIMS_H_INCLUDE
graph prims(graph g);
#endif // PRIMS_INCLUDE
